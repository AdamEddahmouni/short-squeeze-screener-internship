import requests
from bs4 import BeautifulSoup
from urllib.parse import urljoin
from datetime import datetime

def fetch_potential_negative_headlines(ticker, max_headlines=15):
    url = f"https://finviz.com/quote.ashx?t={ticker}"
    headers = {"User-Agent": "Mozilla/5.0"}
    response = requests.get(url, headers=headers)
    soup = BeautifulSoup(response.content, "html.parser")

    news_table = soup.find("table", class_="fullview-news-outer")
    if not news_table:
        return []

    # Negative indicators (edit or expand as needed)
    negative_keywords = [
    "misses", "falls", "drops", "plunges", "declines", "loss",
    "downgraded", "warning", "lawsuit", "recall", "bankruptcy",
    "fraud", "scandal", "resigns", "investigation", "delay",
    "shutdown", "missed expectations", "underperforms",
    "cut", "layoffs", "fined", "miss", "downgrade"
]

    potential_negative_headlines = []

    for row in news_table.find_all("tr"):
        cols = row.find_all("td")
        if len(cols) != 2:
            continue

        link_tag = cols[1].find("a")
        if not link_tag:
            continue

        headline = link_tag.get_text(strip=True)
        url = urljoin("https://finviz.com/", link_tag.get("href", ""))
        timestamp = cols[0].get_text(strip=True)

        # Match any negative indicator
        if any(kw in headline.lower() for kw in negative_keywords):
            potential_negative_headlines.append({
                "headline": headline,
                "timestamp": timestamp,
                "url": url
            })

        if len(potential_negative_headlines) >= max_headlines:
            break

    return potential_negative_headlines

# ▶️ Example usage
if __name__ == "__main__":
    ticker = input("Enter stock ticker (e.g., AAPL): ").strip().upper()
    headlines = fetch_potential_negative_headlines(ticker)
    
    if headlines:
        print(f"\n📰 Suggested Negative Headlines for {ticker}:\n")
        for item in headlines:
            print(f"- {item['headline']} ({item['timestamp']})\n  {item['url']}\n")
    else:
        print("❌ No negative headlines found.")