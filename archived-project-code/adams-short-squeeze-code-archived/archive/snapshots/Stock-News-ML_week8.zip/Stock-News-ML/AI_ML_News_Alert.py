import requests
import time
import joblib
import os
import io
import csv
from playsound import playsound  # pip install playsound==1.2.2
from datetime import datetime, time as dt_time
import pandas as pd
from textblob import TextBlob
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression

# 🔑 Your Finviz Elite API Key
FINVIZ_API_KEY = "cc30b619-0444-43cf-b446-3d2e1c1d7b77"  # Replace with your actual API key

# 🕒 Check if US market is open (Mon–Fri, 9:30am–4:00pm)
def is_market_open():
    now = datetime.now()
    return now.weekday() < 5 and dt_time(9, 30) <= now.time() <= dt_time(16, 0)
    #return True

# 🌐 Fetch all news from Finviz API
def fetch_all_finviz_api_news():
    url = "https://elite.finviz.com/news_export.ashx?v=3&auth=cc30b619-0444-43cf-b446-3d2e1c1d7b77"  # Still correct
    headers = {
        "Authorization": f"Bearer {FINVIZ_API_KEY}",
        "User-Agent": "Mozilla/5.0"
    }

    try:
        response = requests.get(url, headers=headers)
        response.raise_for_status()

        # ✅ Parse CSV instead of JSON
        csv_text = response.text
        csv_reader = csv.DictReader(io.StringIO(csv_text))

        headlines = []
        for row in csv_reader:
            headlines.append({
                "headline": row.get("Title", "No title"),
                "timestamp": row.get("Date", "Unknown time"),
                "url": row.get("Url", "")
            })

        return headlines

    except Exception as e:
        print(f"❌ Error fetching news from Finviz API: {e}")
        return []

# 🧠 Train or load sentiment model
def train_model():
    df = pd.read_csv("Stock-News-ML/data/sample_news.csv", encoding='utf-8')
    X = df['headline']
    y = df['price_movement']

    vectorizer = TfidfVectorizer(stop_words='english')
    X_vec = vectorizer.fit_transform(X)

    model = LogisticRegression()
    model.fit(X_vec, y)

    return model, vectorizer

def train_or_load_model():
    try:
        model = joblib.load("model.pkl")
        vectorizer = joblib.load("vectorizer.pkl")
    except FileNotFoundError:
        model, vectorizer = train_model()
        joblib.dump(model, "model.pkl")
        joblib.dump(vectorizer, "vectorizer.pkl")
    return model, vectorizer

# 📊 Classify headlines using ML and sentiment
def classify_headlines(headlines, model, vectorizer):
    X_vec = vectorizer.transform(headlines)
    predictions = model.predict(X_vec)
    prediction_probs = model.predict_proba(X_vec)

    results = []
    for i, headline in enumerate(headlines):
        sentiment_score = TextBlob(headline).sentiment.polarity
        confidence = round(max(prediction_probs[i]), 3)
        label = '📈 Positive' if predictions[i] == 1 else '📉 Negative'

        results.append({
            'headline': headline,
            'sentiment_score': round(sentiment_score, 3),
            'prediction': label,
            'confidence_score': confidence
        })

    return pd.DataFrame(results)

# 🔔 Main monitoring loop
def run_finviz_news_monitor(model, vectorizer):
    seen_headlines = set()
    print("📡 Monitoring Finviz API news during open hours...")

    while True:
        if not is_market_open():
            print("⏸ Market is closed. Waiting 60s...")
            time.sleep(60)
            continue

        all_news = fetch_all_finviz_api_news()
        new_news = [item for item in all_news if item["headline"] not in seen_headlines]

        if new_news:
            texts = [item["headline"] for item in new_news]
            df = classify_headlines(texts, model, vectorizer)

            for i, row in df.iterrows():
                if row['prediction'] == '📈 Positive' and row['confidence_score'] >= 0.4:
                    print(f"\n🔔 ALERT: Market-Wide Positive News")
                    print(f"📰 {row['headline']}")
                    print(f"📊 Confidence: {row['confidence_score']} | Sentiment: {row['sentiment_score']}")
                    print(f"🔗 URL: {new_news[i]['url']}")
                    try:
                        playsound("Stock-News-ML/alert.mp3")  # Optional sound
                    except Exception as e:
                        print(f"⚠️ Error playing sound: {e}")

                seen_headlines.add(row['headline'])

        else:
            print("✅ No new headlines.")
        
        time.sleep(30)

# ▶️ Entry point
def main():
    model, vectorizer = train_or_load_model()
    run_finviz_news_monitor(model, vectorizer)

if __name__ == "__main__":
    main()