import requests
from bs4 import BeautifulSoup
from urllib.parse import urljoin
from datetime import datetime

def fetch_potential_positive_headlines(ticker, max_headlines=15):
    url = f"https://finviz.com/quote.ashx?t={ticker}"
    headers = {"User-Agent": "Mozilla/5.0"}
    response = requests.get(url, headers=headers)
    soup = BeautifulSoup(response.content, "html.parser")

    news_table = soup.find("table", class_="fullview-news-outer")
    if not news_table:
        return []

    # Positive indicators (edit or expand as needed)
    positive_keywords = [
    "beats", "soars", "surges", "rises", "gains", "record high",
    "tops expectations", "strong", "growth", "outperforms",
    "expands", "acquisition", "buyback", "dividend increase",
    "partnership", "wins", "upgraded", "profit", "revenue up",
    "launch", "launches", "boost", "approval", "FDA approval"
]

    potential_positive_headlines = []

    for row in news_table.find_all("tr"):
        cols = row.find_all("td")
        if len(cols) != 2:
            continue

        link_tag = cols[1].find("a")
        if not link_tag:
            continue

        headline = link_tag.get_text(strip=True)
        url = urljoin("https://finviz.com/", link_tag.get("href", ""))
        timestamp = cols[0].get_text(strip=True)

        # Match any positive indicator
        if any(kw in headline.lower() for kw in positive_keywords):
            potential_positive_headlines.append({
                "headline": headline,
                "timestamp": timestamp,
                "url": url
            })

        if len(potential_positive_headlines) >= max_headlines:
            break

    return potential_positive_headlines

# ▶️ Example usage
if __name__ == "__main__":
    ticker = input("Enter stock ticker (e.g., AAPL): ").strip().upper()
    headlines = fetch_potential_positive_headlines(ticker)
    
    if headlines:
        print(f"\n📰 Suggested Positive Headlines for {ticker}:\n")
        for item in headlines:
            print(f"- {item['headline']} ({item['timestamp']})\n  {item['url']}\n")
    else:
        print("❌ No positive headlines found.")