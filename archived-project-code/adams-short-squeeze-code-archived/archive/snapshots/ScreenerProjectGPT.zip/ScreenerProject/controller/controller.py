import csv
import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from datetime import datetime
from core.sentiment import train_or_load_model, train_model, classify_headlines
from core.filters import get_filtered_stocks  # Make sure this function returns a list of dicts
from core.finviz_api import fetch_all_finviz_api_news
from core.sentiment import classify_headlines
import webbrowser
from core.sentiment import classify_headlines
from core.filters import rank_and_group_stocks

class Controller:


    def __init__(self):
        self.model, self.vectorizer = train_or_load_model()

    

    def label_headline(self, headline, label):
        """
        Save a headline and label to the labeled_data.csv for future model retraining.
        """
        with open("data/labeled_data.csv", mode="a", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow([datetime.now().isoformat(), headline, label])
        print(f"✅ Labeled: '{headline}' as '{label}'")



    def retrain_model(self):
        """
        Train the model from labeled headlines and update the live model reference.
        """
        print("🔄 Retraining sentiment model from labeled data...")
        model = train_model()
        if model:
            self.model = model
            print("✅ Retraining complete.")
        else:
            print("⚠️ Retraining failed. No labeled data.")



    def get_screener_results(self):
        prime, subprime = rank_and_group_stocks()
        results = []

        def classify_batch(batch):
            formatted = []
            for stock in batch:
                ticker = stock.get('Ticker', '')
                headline = stock.get("Headline", "")
                sentiment = ""

                if self.model and headline:
                    df = classify_headlines([headline], self.model, self.vectorizer)
                    if not df.empty:
                        sentiment = f"{df.iloc[0]['prediction']} ({int(df.iloc[0]['confidence_score']*100)}%)"

                formatted.append([
                    ticker,
                    stock.get("Price", "?"),
                    stock.get("Float", "?"),
                    stock.get("RelVolume", "?"),
                    stock.get("ChangePercent", "?"),
                    sentiment
                ])
            return formatted

        prime_results = classify_batch(prime)
        subprime_results = classify_batch(subprime)

        return prime_results, subprime_results

    def classify_single_headline(self, headline):
        if not self.model:
            return None

        df = classify_headlines([headline], self.model, self.vectorizer)
        return df.iloc[0] if not df.empty else None
    


    def get_positive_news(self):
        from core.finviz_api import fetch_all_finviz_api_news

        if not self.model:
            return []

        news = fetch_all_finviz_api_news()
        headlines = [item['headline'] for item in news]
        df = classify_headlines(headlines, self.model, self.vectorizer)

        positive = []
        for i, row in df.iterrows():
            if "Positive" in row['prediction'] and row['confidence_score'] >= 0.6:
                positive.append({
                    "headline": row['headline'],
                    "confidence_score": row['confidence_score'],
                    "tickers": news[i].get("tickers", []),
                    "url": news[i].get("url", "")
                })

        return positive

    def open_url(self, url):
        
        webbrowser.open_new_tab(url)


    def get_predicted_headlines(self):
        if not self.model:
            return []

        headlines = [
            "Stock XYZ jumps after strong earnings report",
            "Market nervous after inflation spike",
            "New product launch sends ABC soaring"
        ]

        df = classify_headlines(headlines, self.model, self.vectorizer)
        return [(row['headline'], row['prediction'], row['confidence_score']) for _, row in df.iterrows()]