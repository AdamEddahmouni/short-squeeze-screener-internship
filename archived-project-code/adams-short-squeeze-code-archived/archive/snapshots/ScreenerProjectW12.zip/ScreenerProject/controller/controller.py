import csv
import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from datetime import datetime
from core.sentiment import train_or_load_model, train_model, classify_headlines
from core.filters import get_filtered_stocks  # Make sure this function returns a list of dicts
from core.finviz_api import fetch_all_finviz_api_news
from core.sentiment import classify_headlines
import webbrowser
from core.sentiment import classify_headlines
from core.filters import rank_and_group_stocks

class Controller:


    def __init__(self):
        self.model, self.vectorizer = train_or_load_model()
        self.news_cache = fetch_all_finviz_api_news()

    

    def get_screener_results(self):
        prime, subprime = rank_and_group_stocks()
        results = []

        def classify_batch(batch):
            formatted = []
            for stock in batch:
                ticker = stock.get('Ticker', '')
                headline = ""

                # ✅ Match to a news headline
                for news in self.news_cache:
                    if ticker in news.get("tickers", []):
                        headline = news.get("headline", "")
                        break

                sentiment = ""
                if self.model and headline:
                    df = classify_headlines([headline], self.model, self.vectorizer)
                    if not df.empty:
                        sentiment = f"{df.iloc[0]['prediction']} ({int(df.iloc[0]['confidence_score']*100)}%)"

                formatted.append([
                    ticker,
                    stock.get("Price", "?"),
                    stock.get("Float", "?"),
                    stock.get("RelVolume", "?"),
                    stock.get("ChangePercent", "?"),
                    stock.get("Target", "?"),
                    stock.get("StopLoss", "?"),
                    sentiment
                ])
            return formatted

        prime_results = classify_batch(prime)
        subprime_results = classify_batch(subprime)

        return prime_results, subprime_results

    def classify_single_headline(self, headline):
        if not self.model:
            return None

        df = classify_headlines([headline], self.model, self.vectorizer)
        return df.iloc[0] if not df.empty else None
    


    def get_positive_news(self):
        from core.finviz_api import fetch_all_finviz_api_news

        if not self.model:
            return []

        news = self.news_cache
        headlines = [item['headline'] for item in news]
        df = classify_headlines(headlines, self.model, self.vectorizer)

        positive = []
        for i, row in df.iterrows():
            if "Positive" in row['prediction'] and row['confidence_score'] >= 0.6:
                positive.append({
                    "headline": row['headline'],
                    "confidence_score": row['confidence_score'],
                    "tickers": news[i].get("tickers", []),
                    "url": news[i].get("url", "")
                })

        return positive

    def open_url(self, url):
        
        webbrowser.open_new_tab(url)


