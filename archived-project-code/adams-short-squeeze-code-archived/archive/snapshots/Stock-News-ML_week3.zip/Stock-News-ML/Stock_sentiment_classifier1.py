import requests
import pandas as pd
from textblob import TextBlob
from sklearn.linear_model import LogisticRegression

# 🔑 Your NewsAPI Key
API_KEY = '46437b2f8e5045d097b85ddfbd92ced7'  # ← Replace with your actual key

# 🔍 Fetch real-time news headlines using ticker
def fetch_news_by_ticker(ticker, page_size=10):
    url = (
        'https://newsapi.org/v2/everything?'
        f'q={ticker}&pageSize={page_size}&sortBy=publishedAt&language=en&apiKey={API_KEY}'
    )
    response = requests.get(url)
    data = response.json()
    articles = data.get('articles', [])
    headlines = [article['title'] for article in articles if article.get('title')]
    return headlines

# 📈 Simple sentiment analysis
def get_sentiment(text):
    return TextBlob(text).sentiment.polarity

# 🧠 Train model from labeled data
def train_model():
    training_data = pd.read_csv("Stock-News-ML/data/sample_news.csv", encoding='utf-8')
    training_data['sentiment'] = training_data['headline'].apply(get_sentiment)
    
    X = training_data[['sentiment']]
    y = training_data['price_movement']
    
    model = LogisticRegression()
    model.fit(X, y)
    return model

# 🧪 Classify real-time news
def classify_headlines(headlines, model):
    results = []
    for headline in headlines:
        sentiment = get_sentiment(headline)
        if -0.05 < sentiment < 0.05:
            label = '😐 Neutral'
        else:
            prediction = model.predict([[sentiment]])[0]
            label = '📈 Positive' if prediction == 1 else '📉 Negative'
        results.append({'headline': headline, 'sentiment': round(sentiment, 3), 'prediction': label})
    return pd.DataFrame(results)

# 🖨️ Main program
def main():
    ticker = input("Enter a stock ticker (e.g., AAPL, TSLA): ").strip().upper()

    print(f"\n🔍 Fetching news for: {ticker}...")
    headlines = fetch_news_by_ticker(ticker)

    if not headlines:
        print("❌ No articles found. Try a different ticker.")
        return

    model = train_model()
    results_df = classify_headlines(headlines, model)

    print("\n📰 Stock Sentiment Analysis Results:\n")
    print(results_df[['headline', 'sentiment', 'prediction']])

if __name__ == "__main__":
    main()