class ScreenerController:
    def __init__(self, view, model):
        self.view = view
        self.model = model
        self.bind_events()

    def bind_events(self):
        self.view.search.bind("<Return>", self.on_search)

    def on_search(self, event):
        symbol = self.view.search.get()
        self.model.set_ticker_symbol(symbol)
        self.model.fetch_finviz_data()
        data = self.model.get_stock_data()

        self.view.price.config(text=f"Share Price: ${data.get('Price', 'N/A')}")
        self.view.change.config(text=f"Percent Change: {data.get('Change', 'N/A')}")
        self.view.rel_vol.config(text=f"Relative Volume: {data.get('Rel Vol', 'N/A')}")
        self.view.float_amount.config(text=f"Float Amount: {data.get('Float', 'N/A')}")

