import requests
from bs4 import BeautifulSoup

class ScreenerModel:
    def __init__(self):
        self.ticker_symbol = ""
        self.stock_data = {}

    def set_ticker_symbol(self, symbol):
        self.ticker_symbol = symbol

    def get_ticker_symbol(self):
        return self.ticker_symbol

    def get_stock_data(self):
        return self.stock_data

    def fetch_finviz_data(self):
        try:
            url = f"https://finviz.com/quote.ashx?t={self.ticker_symbol}"
            headers = {'User-Agent': 'Mozilla/5.0'}
            response = requests.get(url, headers=headers)
            soup = BeautifulSoup(response.content, 'html.parser')

            table = soup.select_one(".snapshot-table2")
            data = {}

            for row in table.select("tr"):
                cells = row.select("td")
                for i in range(0, len(cells), 2):
                    key = cells[i].text.strip()
                    value = cells[i + 1].text.strip()
                    if key in ["Price", "Change", "Rel Volume", "Shs Float"]:
                        if key == "Rel Volume":
                            data["Rel Vol"] = value
                        elif key == "Shs Float":
                            data["Float"] = value
                        else:
                            data[key] = value

            self.stock_data = data
        except Exception as e:
            print(f"Error fetching data: {e}")
            self.stock_data = {}

