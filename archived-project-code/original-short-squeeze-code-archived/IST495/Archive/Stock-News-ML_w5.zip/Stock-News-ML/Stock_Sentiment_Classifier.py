import requests
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from textblob import TextBlob
from bs4 import BeautifulSoup

# 🔑 NewsAPI key
API_KEY = '46437b2f8e5045d097b85ddfbd92ced7'  # Replace with your actual key

# 📰 Fetch news by stock ticker
def fetch_news_by_ticker(ticker, max_articles=10):
    from urllib.parse import urljoin

    url = f"https://finviz.com/quote.ashx?t={ticker}"
    headers = {
        "User-Agent": "Mozilla/5.0"
    }

    response = requests.get(url, headers=headers)
    soup = BeautifulSoup(response.content, "html.parser")

    news_table = soup.find("table", class_="fullview-news-outer")
    if not news_table:
        return []

    headlines = []
    for row in news_table.find_all("tr"):
        cols = row.find_all("td")
        if len(cols) != 2:
            continue

        link_tag = cols[1].find("a")
        if not link_tag:
            continue  # Skip rows without a valid <a> tag

        # ⏰ Timestamp: either full datetime or just time (Finviz format varies)
        timestamp_text = cols[0].get_text(strip=True)

        # 📰 Headline and link
        headline = link_tag.get_text(strip=True)
        article_url = urljoin("https://finviz.com/", link_tag.get("href", ""))

        headlines.append({
            "headline": headline,
            "timestamp": timestamp_text,
            "url": article_url
        })

        if len(headlines) >= max_articles:
            break

    return headlines

# 🧠 Train model using TF-IDF features
def train_model():
    df = pd.read_csv("Stock-News-ML/data/sample_news.csv", encoding='utf-8')
    X = df['headline']
    y = df['price_movement']

    vectorizer = TfidfVectorizer(stop_words='english')
    X_vec = vectorizer.fit_transform(X)

    model = LogisticRegression()
    model.fit(X_vec, y)

    return model, vectorizer

# 📊 Classify new headlines
def classify_headlines(headlines, model, vectorizer):
    X_vec = vectorizer.transform(headlines)
    predictions = model.predict(X_vec)
    results = []

    for i, headline in enumerate(headlines):
        sentiment_score = TextBlob(headline).sentiment.polarity
        if -0.05 < sentiment_score < 0.05:
            label = '😐 Neutral'
        else:
            label = '📈 Positive' if predictions[i] == 1 else '📉 Negative'

        results.append({
            'headline': headline,
            'sentiment_score': round(sentiment_score, 3),
            'prediction': label
        })

    return pd.DataFrame(results)

# ▶️ Main
def main():
    model, vectorizer = train_model()

    while True:
        ticker = input("\nEnter a stock ticker (or 'Q' to quit): ").strip().upper()
        if ticker == "Q":
            print("👋 Exiting the program.")
            break

        headlines = fetch_news_by_ticker(ticker)
        if not headlines:
            print("❌ No news found for that ticker.")
            continue

        print(f"\n🔍 Found {len(headlines)} headlines for {ticker}...")

        headlines_text = [item["headline"] for item in headlines]
        results_df = classify_headlines(headlines_text, model, vectorizer)
        results_df["timestamp"] = [item["timestamp"] for item in headlines]
        results_df["url"] = [item["url"] for item in headlines]

        print("\n📰 Sentiment Results:\n")
        print(results_df[['headline', 'sentiment_score', 'prediction', 'timestamp', 'url']])
if __name__ == "__main__":
    main()